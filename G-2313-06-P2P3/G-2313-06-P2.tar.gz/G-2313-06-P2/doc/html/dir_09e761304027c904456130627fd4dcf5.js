var dir_09e761304027c904456130627fd4dcf5 =
[
    [ "G-2313-06-P2_client.h", "G-2313-06-P2__client_8h.html", "G-2313-06-P2__client_8h" ],
    [ "G-2313-06-P2_client_common_functions.h", "G-2313-06-P2__client__common__functions_8h.html", "G-2313-06-P2__client__common__functions_8h" ],
    [ "G-2313-06-P2_client_err_handlers.h", "G-2313-06-P2__client__err__handlers_8h.html", "G-2313-06-P2__client__err__handlers_8h" ],
    [ "G-2313-06-P2_client_function_handlers.h", "G-2313-06-P2__client__function__handlers_8h.html", "G-2313-06-P2__client__function__handlers_8h" ],
    [ "G-2313-06-P2_files.h", "G-2313-06-P2__files_8h.html", "G-2313-06-P2__files_8h" ],
    [ "G-2313-06-P2_tcp.h", "G-2313-06-P2__tcp_8h.html", "G-2313-06-P2__tcp_8h" ]
];