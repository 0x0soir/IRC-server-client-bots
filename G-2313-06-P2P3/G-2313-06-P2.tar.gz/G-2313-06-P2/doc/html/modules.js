var modules =
[
    [ "Interface", "group__IRCInterface.html", "group__IRCInterface" ]
];