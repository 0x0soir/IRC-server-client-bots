var searchData=
[
  ['socket_5fdesc',['socket_desc',['../G-2313-06-P2__client_8c.html#adeadf7cb6916a10c7142ce7d265ab32a',1,'socket_desc():&#160;G-2313-06-P2_client.c'],['../G-2313-06-P2__client__common__functions_8c.html#adeadf7cb6916a10c7142ce7d265ab32a',1,'socket_desc():&#160;G-2313-06-P2_client.c'],['../G-2313-06-P2__client__err__handlers_8c.html#adeadf7cb6916a10c7142ce7d265ab32a',1,'socket_desc():&#160;G-2313-06-P2_client.c'],['../G-2313-06-P2__client__function__handlers_8c.html#adeadf7cb6916a10c7142ce7d265ab32a',1,'socket_desc():&#160;G-2313-06-P2_client.c'],['../G-2313-06-P2__files_8c.html#adeadf7cb6916a10c7142ce7d265ab32a',1,'socket_desc():&#160;G-2313-06-P2_client.c']]]
];
