var searchData=
[
  ['recibir_20ficheros',['Recibir ficheros',['../server_especial_recibir_ficheros.html',1,'index']]]
];
