var searchData=
[
  ['hilo_20de_20ping_2dpong',['Hilo de PING-PONG',['../client_function_ping.html',1,'index']]],
  ['hilo_20de_20recepción_20de_20datos',['Hilo de recepción de datos',['../client_function_response.html',1,'index']]]
];
