var searchData=
[
  ['data',['data',['../structsrecv.html#ac5ef113d83ca6646b0cc58b757e22f78',1,'srecv']]]
];
