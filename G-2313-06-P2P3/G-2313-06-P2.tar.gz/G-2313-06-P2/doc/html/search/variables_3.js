var searchData=
[
  ['nick',['nick',['../structsrecv.html#abe3a30e845f4f2f6e47aac6583af3166',1,'srecv']]],
  ['nick_5fcliente',['nick_cliente',['../G-2313-06-P2__client_8c.html#ab93a317ee9a27c82844c9128a76b136a',1,'nick_cliente():&#160;G-2313-06-P2_client.c'],['../G-2313-06-P2__client__err__handlers_8c.html#ab93a317ee9a27c82844c9128a76b136a',1,'nick_cliente():&#160;G-2313-06-P2_client.c'],['../G-2313-06-P2__client__function__handlers_8c.html#ab93a317ee9a27c82844c9128a76b136a',1,'nick_cliente():&#160;G-2313-06-P2_client.c'],['../G-2313-06-P2__files_8c.html#ab93a317ee9a27c82844c9128a76b136a',1,'nick_cliente():&#160;G-2313-06-P2_client.c']]]
];
