var searchData=
[
  ['interface',['Interface',['../group__IRCInterface.html',1,'']]]
];
