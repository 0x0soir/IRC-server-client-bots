var searchData=
[
  ['callbaks',['Callbaks',['../group__IRCInterfaceCallbacks.html',1,'']]]
];
