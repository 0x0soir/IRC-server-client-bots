var searchData=
[
  ['enviar_20ficheros',['Enviar ficheros',['../server_especial_enviar_ficheros.html',1,'index']]]
];
