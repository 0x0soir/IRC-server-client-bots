var globals_func =
[
    [ "c", "globals_func.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "t", "globals_func_t.html", null ]
];