var structsrecv =
[
    [ "data", "structsrecv.html#ac5ef113d83ca6646b0cc58b757e22f78", null ],
    [ "filename", "structsrecv.html#a6ec350741c1d09ab84e115dfde89aa82", null ],
    [ "length", "structsrecv.html#af681620ef61aa562c7d575773f156761", null ],
    [ "nick", "structsrecv.html#abe3a30e845f4f2f6e47aac6583af3166", null ]
];