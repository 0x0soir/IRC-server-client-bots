var group__IRCInterface =
[
    [ "Callbaks", "group__IRCInterfaceCallbacks.html", "group__IRCInterfaceCallbacks" ]
];