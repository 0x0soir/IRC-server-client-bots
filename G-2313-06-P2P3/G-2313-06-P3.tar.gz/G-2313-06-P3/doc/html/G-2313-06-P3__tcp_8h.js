var G_2313_06_P3__tcp_8h =
[
    [ "tcp_bind", "G-2313-06-P3__tcp_8h.html#a383b8c763aedca0e2ed838e32073fde6", null ],
    [ "tcp_connect", "G-2313-06-P3__tcp_8h.html#a4e5ce422aa030ac8b3998e858b79cae2", null ],
    [ "tcp_disconnect", "G-2313-06-P3__tcp_8h.html#a2d1f9e76e5da3a7c1e172d1294a33611", null ],
    [ "tcp_listen", "G-2313-06-P3__tcp_8h.html#a14d727cfbcd2ce3c5f4fae5a470a84da", null ],
    [ "tcp_new_accept", "G-2313-06-P3__tcp_8h.html#a6bae59be22b410f157347083f2e43987", null ],
    [ "tcp_new_listen", "G-2313-06-P3__tcp_8h.html#a9c9d03de1e87014ced69f8d36bb37f86", null ],
    [ "tcp_new_open_connection", "G-2313-06-P3__tcp_8h.html#a3e15d12d1405c959da073cabab3a8520", null ],
    [ "tcp_new_socket", "G-2313-06-P3__tcp_8h.html#a25c77773298f02f1e8135829713d7f3a", null ],
    [ "tcp_receive", "G-2313-06-P3__tcp_8h.html#af3354e60e1181adcd72f9f242063fafe", null ],
    [ "tcp_send", "G-2313-06-P3__tcp_8h.html#a1e2b75e457a02f23d433a6821f6902b7", null ]
];