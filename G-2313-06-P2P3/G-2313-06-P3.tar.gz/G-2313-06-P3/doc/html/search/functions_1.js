var searchData=
[
  ['cerrar_5fcanal_5fssl',['cerrar_canal_SSL',['../G-2313-06-P3__ssl_8h.html#a307ee105b4b24b555d8df68603c2deff',1,'cerrar_canal_SSL(SSL *ssl, SSL_CTX *ctl_ssl, int desc):&#160;G-2313-06-P3_ssl.c'],['../G-2313-06-P3__ssl_8c.html#a307ee105b4b24b555d8df68603c2deff',1,'cerrar_canal_SSL(SSL *ssl, SSL_CTX *ctl_ssl, int desc):&#160;G-2313-06-P3_ssl.c']]],
  ['conectar_5fcanal_5fseguro_5fssl',['conectar_canal_seguro_SSL',['../G-2313-06-P3__ssl_8h.html#aa58ddc931cb106d430ab49223b9394fc',1,'conectar_canal_seguro_SSL(SSL_CTX *ctx_ssl, int desc, struct sockaddr res):&#160;G-2313-06-P3_ssl.c'],['../G-2313-06-P3__ssl_8c.html#aa58ddc931cb106d430ab49223b9394fc',1,'conectar_canal_seguro_SSL(SSL_CTX *ctx_ssl, int desc, struct sockaddr res):&#160;G-2313-06-P3_ssl.c']]]
];
