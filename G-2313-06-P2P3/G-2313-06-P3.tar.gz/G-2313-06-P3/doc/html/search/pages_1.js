var searchData=
[
  ['cierre_20de_20un_20canal_20ssl',['Cierre de un canal SSL',['../cerrar_canal_SSL.html',1,'index']]],
  ['conexión_20a_20un_20canal_20ssl',['Conexión a un canal SSL',['../conectar_canal_seguro_SSL.html',1,'index']]],
  ['comprobación_20de_20conexión_20ssl',['Comprobación de conexión SSL',['../evaluar_post_connectar_SSL.html',1,'index']]]
];
