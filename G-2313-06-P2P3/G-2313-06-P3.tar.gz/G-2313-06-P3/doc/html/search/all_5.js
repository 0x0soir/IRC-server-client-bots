var searchData=
[
  ['inicializar_5fnivel_5fssl',['inicializar_nivel_SSL',['../G-2313-06-P3__ssl_8h.html#a32d6d68d1f64d25effa1ea5ec1e6bdb3',1,'inicializar_nivel_SSL(int *desc):&#160;G-2313-06-P3_ssl.c'],['../G-2313-06-P3__ssl_8c.html#a32d6d68d1f64d25effa1ea5ec1e6bdb3',1,'inicializar_nivel_SSL(int *desc):&#160;G-2313-06-P3_ssl.c'],['../inicializar_nivel_SSL.html',1,'index']]]
];
