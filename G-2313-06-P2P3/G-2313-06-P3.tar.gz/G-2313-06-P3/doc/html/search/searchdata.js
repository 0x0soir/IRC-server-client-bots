var indexSectionsWithContent =
{
  0: "acefgimprst",
  1: "g",
  2: "acefimrst",
  3: "acefipr"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Archivos",
  2: "Funciones",
  3: "Páginas"
};

