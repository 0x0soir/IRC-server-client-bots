var searchData=
[
  ['fijar_5fcontexto_5fssl',['fijar_contexto_SSL',['../G-2313-06-P3__ssl_8h.html#a006acb44fc7dae799271a48117f5a398',1,'fijar_contexto_SSL(SSL_CTX *ssl_ctx, char *certFile, char *certRoot):&#160;G-2313-06-P3_ssl.c'],['../G-2313-06-P3__ssl_8c.html#a006acb44fc7dae799271a48117f5a398',1,'fijar_contexto_SSL(SSL_CTX *ssl_ctx, char *certFile, char *certRoot):&#160;G-2313-06-P3_ssl.c']]]
];
