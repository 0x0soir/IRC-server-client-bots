var searchData=
[
  ['recepción_20de_20datos_20vía_20ssl',['Recepción de datos vía SSL',['../recibir_datos_SSL.html',1,'index']]]
];
