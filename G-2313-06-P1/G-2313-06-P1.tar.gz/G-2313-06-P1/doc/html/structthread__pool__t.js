var structthread__pool__t =
[
    [ "global", "structthread__pool__t.html#aaa6e0a9d9c28c3f9be7eccbe8003af23", null ],
    [ "high_level", "structthread__pool__t.html#aa771fc181f63c16346fff1c7eb0d9014", null ],
    [ "idle_queue", "structthread__pool__t.html#a38a9fa0d0ea1060d5bbff8421a92c1c7", null ],
    [ "low_level", "structthread__pool__t.html#a815792ab9c936b06d46ef3e149e5fd88", null ],
    [ "master_interval", "structthread__pool__t.html#ae3eaf8d90ef550166e595286a6175d14", null ],
    [ "master_thread", "structthread__pool__t.html#a9ad8218717dde39eef701a8bce5ca0a1", null ],
    [ "max_size", "structthread__pool__t.html#a978e7f94032dad6e7a373e7bc1896237", null ],
    [ "min_size", "structthread__pool__t.html#a80aa1805a11e2e6e2bf5811fda0ffc26", null ],
    [ "size", "structthread__pool__t.html#a3185c157636a142415699a20042d6dd8", null ],
    [ "task_next", "structthread__pool__t.html#a00ce5a27204f85e624552f7448ba7093", null ],
    [ "worker_queue", "structthread__pool__t.html#a44640e57780a54d437d7589b1c754ac1", null ]
];