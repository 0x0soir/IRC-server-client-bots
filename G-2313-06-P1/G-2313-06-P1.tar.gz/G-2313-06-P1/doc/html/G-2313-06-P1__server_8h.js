var G_2313_06_P1__server_8h =
[
    [ "CLIENT_MESSAGE_MAXSIZE", "G-2313-06-P1__server_8h.html#a97ed8e840fc4086fc86554e6d1277ca8", null ],
    [ "MAX_CONNECTIONS", "G-2313-06-P1__server_8h.html#a053b7859476cc9867ec62c49e68d3fa1", null ],
    [ "MIN_POOL_THREADS", "G-2313-06-P1__server_8h.html#a80c7be19e867e55f90be3fa66cf65300", null ],
    [ "SERVER_PORT", "G-2313-06-P1__server_8h.html#ac42367fe5c999ec6650de83e9d72fe8c", null ],
    [ "FunctionCallBack", "G-2313-06-P1__server_8h.html#ae102cd0a63430b827183f70ce476a887", null ],
    [ "server_accept_connection", "G-2313-06-P1__server_8h.html#ab201db206f26ab6fb26bb0e36dac4589", null ],
    [ "server_check_socket_status", "G-2313-06-P1__server_8h.html#a64f1fffc5903ccf0350845cd21a95b6e", null ],
    [ "server_daemon", "G-2313-06-P1__server_8h.html#aa0e8000b12d9c52fc1e87847d00c9c47", null ],
    [ "server_execute_function", "G-2313-06-P1__server_8h.html#a775161328c3264fb8f96981f7a9c83ae", null ],
    [ "server_exit", "G-2313-06-P1__server_8h.html#a0e947005d451a8f3bf3af01f54b59f11", null ],
    [ "server_start", "G-2313-06-P1__server_8h.html#a85f40553bba77ada6c4329db58f68630", null ],
    [ "server_start_communication", "G-2313-06-P1__server_8h.html#a567404fb6edb67d9035359fef8e5acf3", null ],
    [ "server_start_pool", "G-2313-06-P1__server_8h.html#a48d522cd984dc64ecd084f05416b1a94", null ]
];