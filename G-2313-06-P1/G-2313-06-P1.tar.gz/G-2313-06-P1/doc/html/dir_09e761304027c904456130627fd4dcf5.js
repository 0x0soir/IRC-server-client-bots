var dir_09e761304027c904456130627fd4dcf5 =
[
    [ "G-2313-06-P1_common_functions.h", "G-2313-06-P1__common__functions_8h.html", "G-2313-06-P1__common__functions_8h" ],
    [ "G-2313-06-P1_function_handlers.h", "G-2313-06-P1__function__handlers_8h.html", "G-2313-06-P1__function__handlers_8h" ],
    [ "G-2313-06-P1_list.h", "G-2313-06-P1__list_8h.html", "G-2313-06-P1__list_8h" ],
    [ "G-2313-06-P1_server.h", "G-2313-06-P1__server_8h.html", "G-2313-06-P1__server_8h" ],
    [ "G-2313-06-P1_thread_pool.h", "G-2313-06-P1__thread__pool_8h.html", "G-2313-06-P1__thread__pool_8h" ]
];