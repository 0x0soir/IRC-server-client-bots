var searchData=
[
  ['master_5finterval',['MASTER_INTERVAL',['../G-2313-06-P1__thread__pool_8h.html#a562492e441dc328fba8a344c7206758a',1,'G-2313-06-P1_thread_pool.h']]],
  ['max_5fconnections',['MAX_CONNECTIONS',['../G-2313-06-P1__server_8h.html#a053b7859476cc9867ec62c49e68d3fa1',1,'G-2313-06-P1_server.h']]],
  ['min_5fpool_5fthreads',['MIN_POOL_THREADS',['../G-2313-06-P1__server_8h.html#a80c7be19e867e55f90be3fa66cf65300',1,'G-2313-06-P1_server.h']]]
];
