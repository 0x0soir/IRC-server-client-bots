var indexSectionsWithContent =
{
  0: "acefghilmnpqstw",
  1: "lt",
  2: "g",
  3: "mstw",
  4: "aceghilmnpqstw",
  5: "ft",
  6: "cilmst",
  7: "cfps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "&apos;typedefs&apos;",
  6: "&apos;defines&apos;",
  7: "Páginas"
};

