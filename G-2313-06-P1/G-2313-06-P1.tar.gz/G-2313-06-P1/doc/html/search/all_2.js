var searchData=
[
  ['entry',['entry',['../structtask__t.html#ac812553758f9102a7a674ad29e78f98b',1,'task_t']]]
];
