var searchData=
[
  ['aceptar_5fcanal_5fseguro_5fssl',['aceptar_canal_seguro_SSL',['../G-2313-06-P3__ssl_8h.html#a44410967ff9e0a1b4219c85f0e62e926',1,'aceptar_canal_seguro_SSL(SSL_CTX *ctx_ssl, SSL **ssl, int desc, int puerto, int tam, struct sockaddr_in ip4addr):&#160;G-2313-06-P3_ssl.c'],['../G-2313-06-P3__ssl_8c.html#a44410967ff9e0a1b4219c85f0e62e926',1,'aceptar_canal_seguro_SSL(SSL_CTX *ctx_ssl, SSL **ssl, int desc, int puerto, int tam, struct sockaddr_in ip4addr):&#160;G-2313-06-P3_ssl.c']]]
];
