var searchData=
[
  ['aceptación_20de_20un_20canal_20seguro',['Aceptación de un canal seguro',['../aceptar_canal_seguro_SSL.html',1,'index']]]
];
