var index =
[
    [ "Inicialización de SSL", "inicializar_nivel_SSL.html", [
      [ "Synopsis", "inicializar_nivel_SSL.html#synopsis_1", null ],
      [ "Descripción", "inicializar_nivel_SSL.html#descripcion_1", null ],
      [ "Valores devueltos", "inicializar_nivel_SSL.html#return_1", null ],
      [ "Autores", "inicializar_nivel_SSL.html#authors_1", null ]
    ] ],
    [ "Fijación del contexto SSL", "fijar_contexto_SSL.html", [
      [ "Synopsis", "fijar_contexto_SSL.html#synopsis_6", null ],
      [ "Descripción", "fijar_contexto_SSL.html#descripcion_6", null ],
      [ "Valores devueltos", "fijar_contexto_SSL.html#return_6", null ],
      [ "Autores", "fijar_contexto_SSL.html#authors_6", null ]
    ] ],
    [ "Aceptación de un canal seguro", "aceptar_canal_seguro_SSL.html", [
      [ "Synopsis", "aceptar_canal_seguro_SSL.html#synopsis_2", null ],
      [ "Descripción", "aceptar_canal_seguro_SSL.html#descripcion_2", null ],
      [ "Valores devueltos", "aceptar_canal_seguro_SSL.html#return_2", null ],
      [ "Autores", "aceptar_canal_seguro_SSL.html#authors_2", null ]
    ] ],
    [ "Comprobación de conexión SSL", "evaluar_post_connectar_SSL.html", [
      [ "Synopsis", "evaluar_post_connectar_SSL.html#synopsis_3", null ],
      [ "Descripción", "evaluar_post_connectar_SSL.html#descripcion_3", null ],
      [ "Valores devueltos", "evaluar_post_connectar_SSL.html#return_3", null ],
      [ "Autores", "evaluar_post_connectar_SSL.html#authors_3", null ]
    ] ],
    [ "Envío de datos vía SSL", "enviar_datos_SSL.html", [
      [ "Synopsis", "enviar_datos_SSL.html#synopsis_4", null ],
      [ "Descripción", "enviar_datos_SSL.html#descripcion_4", null ],
      [ "Valores devueltos", "enviar_datos_SSL.html#return_4", null ],
      [ "Autores", "enviar_datos_SSL.html#authors_4", null ]
    ] ],
    [ "Recepción de datos vía SSL", "recibir_datos_SSL.html", [
      [ "Synopsis", "recibir_datos_SSL.html#synopsis_5", null ],
      [ "Descripción", "recibir_datos_SSL.html#descripcion_5", null ],
      [ "Valores devueltos", "recibir_datos_SSL.html#return_5", null ],
      [ "Autores", "recibir_datos_SSL.html#authors_5", null ]
    ] ],
    [ "Cierre de un canal SSL", "cerrar_canal_SSL.html", [
      [ "Synopsis", "cerrar_canal_SSL.html#synopsis_7", null ],
      [ "Descripción", "cerrar_canal_SSL.html#descripcion_7", null ],
      [ "Valores devueltos", "cerrar_canal_SSL.html#return_7", null ],
      [ "Autores", "cerrar_canal_SSL.html#authors_7", null ]
    ] ],
    [ "Conexión a un canal SSL", "conectar_canal_seguro_SSL.html", [
      [ "Synopsis", "conectar_canal_seguro_SSL.html#synopsis_8", null ],
      [ "Descripción", "conectar_canal_seguro_SSL.html#descripcion_8", null ]
    ] ]
];