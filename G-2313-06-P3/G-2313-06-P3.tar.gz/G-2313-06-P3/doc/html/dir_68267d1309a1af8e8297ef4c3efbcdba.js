var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "G-2313-06-P3_client_echo.c", "G-2313-06-P3__client__echo_8c.html", "G-2313-06-P3__client__echo_8c" ],
    [ "G-2313-06-P3_server_echo.c", "G-2313-06-P3__server__echo_8c.html", "G-2313-06-P3__server__echo_8c" ]
];