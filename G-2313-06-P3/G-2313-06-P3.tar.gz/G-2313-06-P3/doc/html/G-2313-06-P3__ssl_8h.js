var G_2313_06_P3__ssl_8h =
[
    [ "aceptar_canal_seguro_SSL", "G-2313-06-P3__ssl_8h.html#a44410967ff9e0a1b4219c85f0e62e926", null ],
    [ "cerrar_canal_SSL", "G-2313-06-P3__ssl_8h.html#a307ee105b4b24b555d8df68603c2deff", null ],
    [ "conectar_canal_seguro_SSL", "G-2313-06-P3__ssl_8h.html#aa58ddc931cb106d430ab49223b9394fc", null ],
    [ "enviar_datos_SSL", "G-2313-06-P3__ssl_8h.html#adf9cb4f6b9c27081fcf12a942db1b288", null ],
    [ "evaluar_post_connectar_SSL", "G-2313-06-P3__ssl_8h.html#ac5f32cf09e3c0efd5cbc25452ed192a9", null ],
    [ "fijar_contexto_SSL", "G-2313-06-P3__ssl_8h.html#a006acb44fc7dae799271a48117f5a398", null ],
    [ "inicializar_nivel_SSL", "G-2313-06-P3__ssl_8h.html#a32d6d68d1f64d25effa1ea5ec1e6bdb3", null ],
    [ "recibir_datos_SSL", "G-2313-06-P3__ssl_8h.html#af7dca116c6dbb68e9609293102c208c5", null ],
    [ "ssl_start_client", "G-2313-06-P3__ssl_8h.html#a0fc205ff57c9c0a489d8154f94cd2f4a", null ],
    [ "ssl_start_server", "G-2313-06-P3__ssl_8h.html#a6dcf2890813db3e4f8f2f423716d4883", null ]
];