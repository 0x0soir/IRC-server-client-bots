#include <stdio.h>
#include "../includes/G-2313-06-P3_ssl.h"

int main(int argc, char ** argv){
	ssl_start_server();
	return 1;
}
