var G_2313_06_P1__common__functions_8h =
[
    [ "server_channels_find_by_name", "G-2313-06-P1__common__functions_8h.html#a875ae5278d95716b494b26f96cf4ae6e", null ],
    [ "server_channels_update_away", "G-2313-06-P1__common__functions_8h.html#af9aeb632d55a4cbbe842ab97001b5128", null ],
    [ "server_channels_update_nick", "G-2313-06-P1__common__functions_8h.html#ae8a282d9cdfc8187b8e74e368bc56d92", null ],
    [ "server_channels_update_whois", "G-2313-06-P1__common__functions_8h.html#a5c6f52d9a2461877178a1a0905d14ea9", null ],
    [ "server_return_user", "G-2313-06-P1__common__functions_8h.html#a230bf24ab7ae18d2e81ebc1d3575a6ad", null ],
    [ "server_users_find_by_nick", "G-2313-06-P1__common__functions_8h.html#a61cca6f1a1adeb81f722ecc2ff35aab5", null ],
    [ "server_users_find_by_socket", "G-2313-06-P1__common__functions_8h.html#a485e68f66db6ae4b7297d99c32afe30a", null ]
];