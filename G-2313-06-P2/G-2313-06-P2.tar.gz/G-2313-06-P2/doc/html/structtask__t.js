var structtask__t =
[
    [ "arg", "structtask__t.html#a9162b404bd1cf5349b2092f69e31c613", null ],
    [ "entry", "structtask__t.html#ac812553758f9102a7a674ad29e78f98b", null ],
    [ "task_callback", "structtask__t.html#ac8c2d416888e415fc6ee54410a4c511c", null ]
];