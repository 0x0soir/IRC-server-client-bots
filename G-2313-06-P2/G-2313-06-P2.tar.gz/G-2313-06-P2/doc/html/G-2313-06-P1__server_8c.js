var G_2313_06_P1__server_8c =
[
    [ "main", "G-2313-06-P1__server_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "server_accept_connection", "G-2313-06-P1__server_8c.html#aaac8642d2e699e0f9d942d28a9b233c2", null ],
    [ "server_check_socket_status", "G-2313-06-P1__server_8c.html#a64f1fffc5903ccf0350845cd21a95b6e", null ],
    [ "server_daemon", "G-2313-06-P1__server_8c.html#aa0e8000b12d9c52fc1e87847d00c9c47", null ],
    [ "server_execute_function", "G-2313-06-P1__server_8c.html#a775161328c3264fb8f96981f7a9c83ae", null ],
    [ "server_exit", "G-2313-06-P1__server_8c.html#a0e947005d451a8f3bf3af01f54b59f11", null ],
    [ "server_start", "G-2313-06-P1__server_8c.html#aa8cae03a9b52c7a550cbbdcc8aa74ede", null ],
    [ "server_start_communication", "G-2313-06-P1__server_8c.html#a81394df6131e7cf998bd06f63f9e3995", null ],
    [ "server_start_pool", "G-2313-06-P1__server_8c.html#a48d522cd984dc64ecd084f05416b1a94", null ],
    [ "pool", "G-2313-06-P1__server_8c.html#a57d8a6a060b67bdc5946cd0e7331575a", null ]
];