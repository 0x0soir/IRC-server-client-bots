var G_2313_06_P2__files_8c =
[
    [ "server_especial_enviar_ficheros", "G-2313-06-P2__files_8c.html#ad00af19306b45db3947f1b89ae4b5def", null ],
    [ "server_especial_recibir_ficheros", "G-2313-06-P2__files_8c.html#a6796f20636727f52161d02748cb2b17e", null ],
    [ "nick_cliente", "G-2313-06-P2__files_8c.html#ab93a317ee9a27c82844c9128a76b136a", null ],
    [ "socket_desc", "G-2313-06-P2__files_8c.html#adeadf7cb6916a10c7142ce7d265ab32a", null ]
];