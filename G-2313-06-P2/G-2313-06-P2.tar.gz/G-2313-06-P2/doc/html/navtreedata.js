var NAVTREE =
[
  [ "Redes de Comunicaciones II", "index.html", [
    [ "P1 - Servidor IRC", "index.html", "index" ],
    [ "Clases", null, [
      [ "Lista de clases", "annotated.html", "annotated" ],
      [ "Índice de clases", "classes.html", null ],
      [ "Miembros de las clases", "functions.html", [
        [ "Todo", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Archivos", null, [
      [ "Lista de archivos", "files.html", "files" ],
      [ "Miembros de los ficheros", "globals.html", [
        [ "Todo", "globals.html", null ],
        [ "Funciones", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", null ],
        [ "'typedefs'", "globals_type.html", null ],
        [ "'defines'", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"G-2313-06-P1__common__functions_8c.html",
"server_commands.html#cabeceras3"
];

var SYNCONMSG = 'click en deshabilitar sincronización';
var SYNCOFFMSG = 'click en habilitar sincronización';