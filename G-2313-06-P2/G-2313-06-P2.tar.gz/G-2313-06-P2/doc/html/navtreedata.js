var NAVTREE =
[
  [ "Redes de Comunicaciones II", "index.html", [
    [ "P2 - Cliente IRC", "index.html", "index" ],
    [ "Módulos", "modules.html", "modules" ],
    [ "Clases", "annotated.html", [
      [ "Lista de clases", "annotated.html", "annotated_dup" ],
      [ "Índice de clases", "classes.html", null ],
      [ "Miembros de las clases", "functions.html", [
        [ "Todo", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Archivos", null, [
      [ "Lista de archivos", "files.html", "files" ],
      [ "Miembros de los ficheros", "globals.html", [
        [ "Todo", "globals.html", "globals_dup" ],
        [ "Funciones", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"G-2313-06-P2__client_8c.html",
"G-2313-06-P2__tcp_8c.html#a2d1f9e76e5da3a7c1e172d1294a33611"
];

var SYNCONMSG = 'click en deshabilitar sincronización';
var SYNCOFFMSG = 'click en habilitar sincronización';