var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "G-2313-06-P1_common_functions.c", "G-2313-06-P1__common__functions_8c.html", "G-2313-06-P1__common__functions_8c" ],
    [ "G-2313-06-P1_function_handlers.c", "G-2313-06-P1__function__handlers_8c.html", "G-2313-06-P1__function__handlers_8c" ],
    [ "G-2313-06-P1_server.c", "G-2313-06-P1__server_8c.html", "G-2313-06-P1__server_8c" ],
    [ "G-2313-06-P1_thread_pool.c", "G-2313-06-P1__thread__pool_8c.html", "G-2313-06-P1__thread__pool_8c" ]
];