var annotated_dup =
[
    [ "srecv", "structsrecv.html", "structsrecv" ]
];