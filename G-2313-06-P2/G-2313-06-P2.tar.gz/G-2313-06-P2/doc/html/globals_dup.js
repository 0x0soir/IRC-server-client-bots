var globals_dup =
[
    [ "c", "globals.html", null ],
    [ "i", "globals_i.html", null ],
    [ "m", "globals_m.html", null ],
    [ "n", "globals_n.html", null ],
    [ "s", "globals_s.html", null ],
    [ "t", "globals_t.html", null ]
];