var structlist__head =
[
    [ "next", "structlist__head.html#ac3b0ff0dfb978a0cfbdad6b9d19cdcfe", null ],
    [ "prev", "structlist__head.html#aaa0eabda8877e1d6de73a33f223ad004", null ]
];