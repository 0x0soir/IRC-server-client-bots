var server_connection =
[
    [ "Cabeceras", "server_connection.html#cabeceras", null ],
    [ "Variables definidas", "server_connection.html#variables", null ],
    [ "Funciones implementadas", "server_connection.html#functions", null ],
    [ "server_start", "server_start.html", [
      [ "Synopsis", "server_start.html#synopsis2", null ],
      [ "Descripción", "server_start.html#descripcion2", null ],
      [ "Valores devueltos", "server_start.html#return2", null ],
      [ "Autores", "server_start.html#authors2", null ]
    ] ],
    [ "server_accept_connection", "server_accept_connection.html", [
      [ "Synopsis", "server_accept_connection.html#synopsis3", null ],
      [ "Descripción", "server_accept_connection.html#descripcion3", null ],
      [ "Valores devueltos", "server_accept_connection.html#return3", null ],
      [ "Autores", "server_accept_connection.html#authors3", null ]
    ] ],
    [ "server_start_communication", "server_start_communication.html", [
      [ "Synopsis", "server_start_communication.html#synopsis4", null ],
      [ "Descripción", "server_start_communication.html#descripcion4", null ],
      [ "Valores devueltos", "server_start_communication.html#return4", null ],
      [ "Autores", "server_start_communication.html#authors4", null ]
    ] ],
    [ "server_execute_function", "server_execute_function.html", [
      [ "Synopsis", "server_execute_function.html#synopsis5", null ],
      [ "Descripción", "server_execute_function.html#descripcion5", null ],
      [ "Valores devueltos", "server_execute_function.html#return5", null ],
      [ "Autores", "server_execute_function.html#authors5", null ]
    ] ],
    [ "server_exit", "server_exit.html", [
      [ "Synopsis", "server_exit.html#synopsis6", null ],
      [ "Descripción", "server_exit.html#descripcion6", null ],
      [ "Valores devueltos", "server_exit.html#return6", null ],
      [ "Autores", "server_exit.html#authors6", null ]
    ] ],
    [ "server_check_socket_status", "server_check_socket_status.html", [
      [ "Synopsis", "server_check_socket_status.html#Synopsis", null ],
      [ "Descripción", "server_check_socket_status.html#descripcion", null ],
      [ "Valores devueltos", "server_check_socket_status.html#return", null ],
      [ "Autores", "server_check_socket_status.html#authors", null ]
    ] ],
    [ "server_daemon", "server_daemon.html", [
      [ "Synopsis", "server_daemon.html#synopsis7", null ],
      [ "Descripción", "server_daemon.html#descripcion7", null ],
      [ "Valores devueltos", "server_daemon.html#return7", null ],
      [ "Autores", "server_daemon.html#authors7", null ]
    ] ],
    [ "server_start_pool", "server_start_pool.html", [
      [ "Synopsis", "server_start_pool.html#synopsis8", null ],
      [ "Descripción", "server_start_pool.html#descripcion8", null ],
      [ "Valores devueltos", "server_start_pool.html#return8", null ],
      [ "Autores", "server_start_pool.html#authors8", null ]
    ] ]
];