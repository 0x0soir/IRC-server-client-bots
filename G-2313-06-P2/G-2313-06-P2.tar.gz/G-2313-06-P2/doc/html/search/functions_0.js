var searchData=
[
  ['main',['main',['../G-2313-06-P1__server_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'G-2313-06-P1_server.c']]],
  ['master_5fcallback',['master_callback',['../G-2313-06-P1__thread__pool_8h.html#a54703c23462be974a5e2511247921922',1,'master_callback(void *arg):&#160;G-2313-06-P1_thread_pool.c'],['../G-2313-06-P1__thread__pool_8c.html#a54703c23462be974a5e2511247921922',1,'master_callback(void *arg):&#160;G-2313-06-P1_thread_pool.c']]]
];
