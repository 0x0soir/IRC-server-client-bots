var searchData=
[
  ['worker_5fcallback',['worker_callback',['../G-2313-06-P1__thread__pool_8h.html#a4ef081fb21acd34e0e2492a9f290b6a3',1,'worker_callback(void *arg):&#160;G-2313-06-P1_thread_pool.c'],['../G-2313-06-P1__thread__pool_8c.html#a4ef081fb21acd34e0e2492a9f290b6a3',1,'worker_callback(void *arg):&#160;G-2313-06-P1_thread_pool.c']]]
];
