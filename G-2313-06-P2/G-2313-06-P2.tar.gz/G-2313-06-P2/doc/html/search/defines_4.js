var searchData=
[
  ['server_5fport',['SERVER_PORT',['../G-2313-06-P1__server_8h.html#ac42367fe5c999ec6650de83e9d72fe8c',1,'G-2313-06-P1_server.h']]]
];
