var searchData=
[
  ['pool',['pool',['../structthread__args.html#a425ced5f77dcbb52f61d240a4e207a27',1,'thread_args::pool()'],['../G-2313-06-P1__server_8c.html#a57d8a6a060b67bdc5946cd0e7331575a',1,'pool():&#160;G-2313-06-P1_server.c']]],
  ['prev',['prev',['../structlist__head.html#aaa0eabda8877e1d6de73a33f223ad004',1,'list_head']]]
];
