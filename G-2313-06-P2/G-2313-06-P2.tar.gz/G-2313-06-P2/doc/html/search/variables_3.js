var searchData=
[
  ['global',['global',['../structthread__pool__t.html#aaa6e0a9d9c28c3f9be7eccbe8003af23',1,'thread_pool_t']]]
];
