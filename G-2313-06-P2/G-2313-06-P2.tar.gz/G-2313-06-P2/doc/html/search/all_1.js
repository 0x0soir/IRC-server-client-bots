var searchData=
[
  ['client_5fmessage_5fmaxsize',['CLIENT_MESSAGE_MAXSIZE',['../G-2313-06-P1__server_8h.html#a97ed8e840fc4086fc86554e6d1277ca8',1,'G-2313-06-P1_server.h']]],
  ['cond',['cond',['../structthread__t.html#a6cb846b84c59d01a8b3a2693d39a4af1',1,'thread_t']]],
  ['current',['current',['../structthread__args.html#a191f3ea514283452d04bde31cde4c7ad',1,'thread_args']]],
  ['comandos',['Comandos',['../server_commands.html',1,'index']]],
  ['conexión_20del_20servidor',['Conexión del servidor',['../server_connection.html',1,'index']]]
];
