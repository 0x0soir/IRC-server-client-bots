var searchData=
[
  ['idle_5fentry',['idle_entry',['../structthread__t.html#a9386032d478cacdfd680d5691e0eb9d3',1,'thread_t']]],
  ['idle_5fqueue',['idle_queue',['../structthread__pool__t.html#a38a9fa0d0ea1060d5bbff8421a92c1c7',1,'thread_pool_t']]]
];
