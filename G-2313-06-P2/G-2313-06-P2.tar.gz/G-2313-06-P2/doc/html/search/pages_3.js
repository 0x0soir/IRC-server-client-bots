var searchData=
[
  ['parseo_20de_20entradas',['Parseo de entradas',['../client_execute_in_function.html',1,'index']]],
  ['parseo_20de_20salidas',['Parseo de salidas',['../client_execute_out_function.html',1,'index']]],
  ['preprocesado_20de_20entradas',['Preprocesado de entradas',['../client_pre_in_function.html',1,'index']]],
  ['preprocesado_20de_20salidas',['Preprocesado de salidas',['../client_pre_out_function.html',1,'index']]],
  ['p2_20_2d_20cliente_20irc',['P2 - Cliente IRC',['../index.html',1,'']]]
];
