var searchData=
[
  ['client_5fmessage_5fmaxsize',['CLIENT_MESSAGE_MAXSIZE',['../G-2313-06-P1__server_8h.html#a97ed8e840fc4086fc86554e6d1277ca8',1,'G-2313-06-P1_server.h']]]
];
