var searchData=
[
  ['tcp_5fconnect',['tcp_connect',['../G-2313-06-P2__tcp_8h.html#a4e5ce422aa030ac8b3998e858b79cae2',1,'tcp_connect(char *server, int port):&#160;G-2313-06-P2_tcp.c'],['../G-2313-06-P2__tcp_8c.html#a4e5ce422aa030ac8b3998e858b79cae2',1,'tcp_connect(char *server, int port):&#160;G-2313-06-P2_tcp.c']]],
  ['tcp_5fdisconnect',['tcp_disconnect',['../G-2313-06-P2__tcp_8h.html#a2d1f9e76e5da3a7c1e172d1294a33611',1,'tcp_disconnect(int fd):&#160;G-2313-06-P2_tcp.c'],['../G-2313-06-P2__tcp_8c.html#a2d1f9e76e5da3a7c1e172d1294a33611',1,'tcp_disconnect(int fd):&#160;G-2313-06-P2_tcp.c']]],
  ['tcp_5flisten',['tcp_listen',['../G-2313-06-P2__tcp_8h.html#a14d727cfbcd2ce3c5f4fae5a470a84da',1,'tcp_listen(int port, int max_conn):&#160;G-2313-06-P2_tcp.c'],['../G-2313-06-P2__tcp_8c.html#a14d727cfbcd2ce3c5f4fae5a470a84da',1,'tcp_listen(int port, int max_conn):&#160;G-2313-06-P2_tcp.c']]],
  ['tcp_5freceive',['tcp_receive',['../G-2313-06-P2__tcp_8h.html#af3354e60e1181adcd72f9f242063fafe',1,'tcp_receive(int fd, char *msg, int len):&#160;G-2313-06-P2_tcp.c'],['../G-2313-06-P2__tcp_8c.html#af3354e60e1181adcd72f9f242063fafe',1,'tcp_receive(int fd, char *msg, int len):&#160;G-2313-06-P2_tcp.c']]],
  ['tcp_5fsend',['tcp_send',['../G-2313-06-P2__tcp_8h.html#a1e2b75e457a02f23d433a6821f6902b7',1,'tcp_send(int fd, char *msg):&#160;G-2313-06-P2_tcp.c'],['../G-2313-06-P2__tcp_8c.html#a1e2b75e457a02f23d433a6821f6902b7',1,'tcp_send(int fd, char *msg):&#160;G-2313-06-P2_tcp.c']]]
];
