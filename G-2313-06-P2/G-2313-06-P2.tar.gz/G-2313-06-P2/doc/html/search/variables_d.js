var searchData=
[
  ['worker_5fentry',['worker_entry',['../structthread__t.html#a03432229de426c5ba35d0dfa325491f0',1,'thread_t']]],
  ['worker_5fqueue',['worker_queue',['../structthread__pool__t.html#a44640e57780a54d437d7589b1c754ac1',1,'thread_pool_t']]]
];
