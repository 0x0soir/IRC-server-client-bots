var searchData=
[
  ['init_5flist_5fhead',['INIT_LIST_HEAD',['../G-2313-06-P1__list_8h.html#a0ffe9d28c36d7b018a9cfae33bae45c0',1,'G-2313-06-P1_list.h']]]
];
