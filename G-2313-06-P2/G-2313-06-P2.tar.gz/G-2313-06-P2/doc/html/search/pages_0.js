var searchData=
[
  ['comandos',['Comandos',['../server_commands.html',1,'index']]],
  ['conexión_20del_20servidor',['Conexión del servidor',['../server_connection.html',1,'index']]]
];
