var index =
[
    [ "Hilo de PING-PONG", "client_function_ping.html", [
      [ "Synopsis", "client_function_ping.html#synopsis_1", null ],
      [ "Descripción", "client_function_ping.html#descripcion_1", null ],
      [ "Valores devueltos", "client_function_ping.html#return_1", null ],
      [ "Autores", "client_function_ping.html#authors_1", null ]
    ] ],
    [ "Hilo de recepción de datos", "client_function_response.html", [
      [ "Synopsis", "client_function_response.html#synopsis_2", null ],
      [ "Descripción", "client_function_response.html#descripcion_2", null ],
      [ "Valores devueltos", "client_function_response.html#return_2", null ],
      [ "Autores", "client_function_response.html#authors_2", null ]
    ] ],
    [ "Enviar ficheros", "server_especial_enviar_ficheros.html", [
      [ "Synopsis", "server_especial_enviar_ficheros.html#synopsis_file", null ],
      [ "Descripción", "server_especial_enviar_ficheros.html#descripcion_file", null ],
      [ "Autores", "server_especial_enviar_ficheros.html#authors_file", null ]
    ] ],
    [ "Recibir ficheros", "server_especial_recibir_ficheros.html", [
      [ "Synopsis", "server_especial_recibir_ficheros.html#synopsis_file_2", null ],
      [ "Descripción", "server_especial_recibir_ficheros.html#descripcion_file_2", null ],
      [ "Autores", "server_especial_recibir_ficheros.html#authors_file_2", null ]
    ] ],
    [ "Preprocesado de entradas", "client_pre_in_function.html", [
      [ "Synopsis", "client_pre_in_function.html#synopsis_3", null ],
      [ "Descripción", "client_pre_in_function.html#descripcion_3", null ],
      [ "Valores devueltos", "client_pre_in_function.html#return_3", null ],
      [ "Autores", "client_pre_in_function.html#authors_3", null ]
    ] ],
    [ "Parseo de entradas", "client_execute_in_function.html", [
      [ "Synopsis", "client_execute_in_function.html#synopsis_4", null ],
      [ "Descripción", "client_execute_in_function.html#descripcion_4", null ],
      [ "Valores devueltos", "client_execute_in_function.html#return_4", null ],
      [ "Autores", "client_execute_in_function.html#authors_4", null ]
    ] ],
    [ "Preprocesado de salidas", "client_pre_out_function.html", [
      [ "Synopsis", "client_pre_out_function.html#synopsis_5", null ],
      [ "Descripción", "client_pre_out_function.html#descripcion_5", null ],
      [ "Valores devueltos", "client_pre_out_function.html#return_5", null ],
      [ "Autores", "client_pre_out_function.html#authors_5", null ]
    ] ],
    [ "Parseo de salidas", "client_execute_out_function.html", [
      [ "Synopsis", "client_execute_out_function.html#synopsis_6", null ],
      [ "Descripción", "client_execute_out_function.html#descripcion_6", null ],
      [ "Valores devueltos", "client_execute_out_function.html#return_6", null ],
      [ "Autores", "client_execute_out_function.html#authors_6", null ]
    ] ]
];