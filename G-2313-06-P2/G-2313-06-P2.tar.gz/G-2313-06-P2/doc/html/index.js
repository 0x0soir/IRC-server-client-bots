var index =
[
    [ "Conexión del servidor", "server_connection.html", "server_connection" ],
    [ "Funciones auxiliares", "server_common_functions.html", "server_common_functions" ],
    [ "Comandos", "server_commands.html", "server_commands" ]
];