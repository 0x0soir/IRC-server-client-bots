var G_2313_06_P2__files_8h =
[
    [ "srecv", "structsrecv.html", "structsrecv" ],
    [ "server_especial_enviar_ficheros", "G-2313-06-P2__files_8h.html#ad00af19306b45db3947f1b89ae4b5def", null ],
    [ "server_especial_recibir_ficheros", "G-2313-06-P2__files_8h.html#a6796f20636727f52161d02748cb2b17e", null ]
];