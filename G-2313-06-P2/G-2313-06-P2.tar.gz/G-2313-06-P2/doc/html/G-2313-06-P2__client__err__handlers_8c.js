var G_2313_06_P2__client__err__handlers_8c =
[
    [ "server_in_command_err_alreadyregistred", "G-2313-06-P2__client__err__handlers_8c.html#a14bfb17eb95d0f2bef1869aa2ebf520c", null ],
    [ "server_in_command_err_bannedfromchan", "G-2313-06-P2__client__err__handlers_8c.html#a0e4059ef132eaac2218fdd89b20ca852", null ],
    [ "server_in_command_err_cannotsendtochan", "G-2313-06-P2__client__err__handlers_8c.html#aee5973ae831d1c7c63b1a62b59f561c2", null ],
    [ "server_in_command_err_channelisfull", "G-2313-06-P2__client__err__handlers_8c.html#a05db0aa32f2ec2925cba3b952435bf59", null ],
    [ "server_in_command_err_chanoprivsneeded", "G-2313-06-P2__client__err__handlers_8c.html#a9fcb3f66fbcc994c7a78b36ebc0fe63d", null ],
    [ "server_in_command_err_erroneusnickname", "G-2313-06-P2__client__err__handlers_8c.html#abeb8ead21ebba982eb59f161eda735cb", null ],
    [ "server_in_command_err_inviteonlychan", "G-2313-06-P2__client__err__handlers_8c.html#ae5512c3dd8e1584fd8bafc4f5dd15d8c", null ],
    [ "server_in_command_err_nickcollision", "G-2313-06-P2__client__err__handlers_8c.html#a4af95b292b293c08c0989b4e7334c7eb", null ],
    [ "server_in_command_err_nicknameinuse", "G-2313-06-P2__client__err__handlers_8c.html#ab6d8f2d05566bf6ee9dfcfc4a20f5d23", null ],
    [ "server_in_command_err_nochanmodes", "G-2313-06-P2__client__err__handlers_8c.html#aade31864807344a9961ffdab697b5727", null ],
    [ "server_in_command_err_nomotd", "G-2313-06-P2__client__err__handlers_8c.html#a678f368edc1fd437f5f115ef897bdcd9", null ],
    [ "server_in_command_err_nonicknamegiven", "G-2313-06-P2__client__err__handlers_8c.html#aaa9cfb1b5050bd1218c227d8d0a041fe", null ],
    [ "server_in_command_err_nosuchchannel", "G-2313-06-P2__client__err__handlers_8c.html#a83109e15e2a8f93c9523a84a546098c0", null ],
    [ "server_in_command_err_nosuchnick", "G-2313-06-P2__client__err__handlers_8c.html#a01f8c9822aac18d5424ebbaf67c06a51", null ],
    [ "server_in_command_err_passwdmismatch", "G-2313-06-P2__client__err__handlers_8c.html#a548a7ad35236521dca4b829e466f3379", null ],
    [ "server_in_command_err_restricted", "G-2313-06-P2__client__err__handlers_8c.html#ada432444f58d5effbb05fd558a8ce289", null ],
    [ "server_in_command_err_unavailresource", "G-2313-06-P2__client__err__handlers_8c.html#ae4fcb567dc7685f5d7a4abbc7c6506b4", null ],
    [ "server_in_command_err_unknownmode", "G-2313-06-P2__client__err__handlers_8c.html#af262f3569e06c21e3e466266fa4e2c80", null ],
    [ "nick_cliente", "G-2313-06-P2__client__err__handlers_8c.html#ab93a317ee9a27c82844c9128a76b136a", null ],
    [ "socket_desc", "G-2313-06-P2__client__err__handlers_8c.html#adeadf7cb6916a10c7142ce7d265ab32a", null ]
];