var structthread__args =
[
    [ "current", "structthread__args.html#a191f3ea514283452d04bde31cde4c7ad", null ],
    [ "pool", "structthread__args.html#a425ced5f77dcbb52f61d240a4e207a27", null ]
];